#!/bin/bash

echo " "
echo "################################################"
echo 
echo It is recommended that you install the ZRT client on one of the primary or replica LDAP servers using the Zimbra account.  DO NOT install the ZRT client more than once on a multi-master or replica LDAP server in a multi-server instance.  ZC instance must only have one installed ZRT client, or double counting will occur.
echo 
echo If installed on a ZC server, the ZRT client will attempt to self configure and will report the count using the LDAP that is listed within the first instance within ldap_master_url.
echo 
echo If the ZRT client has been previously installed on the system within a different directory, please verify that all crontab entries have been removed.  
echo 
echo To install the ZRT client, you will need to obtain the ZRT user license from Zimbra Sales or Support.  
echo 
echo For questions regarding the installation process, or to report an installation issue,  please log into your Zimbra Support account at https://support.zimbra.com and open a support case for assistance.  For more information about installation, please see the ZRT client installation guide.
echo 
echo "################################################"
echo " "
echo "Checking for an installed version of Java..."
if type -p java; then
    echo Found java executable in PATH.
    _java=java
elif [[ -n "$JAVA_HOME" ]] && [[ -x "$JAVA_HOME/bin/java" ]];  then
    echo Found java executable in JAVA_HOME     
    _java="$JAVA_HOME/bin/java"
else
    echo "ERROR: There was not a valid Java version installed.  Please install a version and set a JAVA_HOME system variable, then re-run the installation."
	exit
fi

if [[ "$_java" ]]; then
    version=$("$_java" -version 2>&1 | awk -F '"' '/version/ {print $2}')
    echo Installed Java version "$version"
    if [[ "$version" > "1.5" ]]; then
        echo Java version is 1.6 or higher.
    else         
	    echo "ERROR: There was not a valid Java version installed. This application requires a newer version. Please install a more recent version and set a JAVA_HOME system variable, then re-run the installation"
    	exit
    fi
fi

echo ""
echo Your current directory is: $(pwd)
read -p "Please provide the path you wish to install the ZRT client or hit enter to use the default path of '/opt/zrt': " INSTALLPATH

# CHECK THE INPUT OF THE INSTALL PATH
if [ ! -z "$INSTALLPATH" -a "$INSTALLPATH" != " " ]; then
echo You entered: $INSTALLPATH
else
echo "Using the default path of '/opt/zrt'"
INSTALLPATH="/opt/zrt"
fi

if [[ -d "${INSTALLPATH}" && ! -L "${INSTALLPATH}" && -w "${INSTALLPATH}" ]] ; then
echo ""
else
	echo The folder "$INSTALLPATH" does not exist or does not have the correct permissions.  
	echo The installation process will terminate do to folder issues.
	exit 0
fi

if which zmlocalconfig >/dev/null; then

	if [ "${USER}" = "zimbra" ]; then
		LDAP_URL_VALUE_EXAMPLE=`zmlocalconfig ldap_master_url | grep "ldap_master_url" | cut -d'=' -f2`
		echo "LDAP URL from system: $LDAP_URL_VALUE_EXAMPLE "
		LDAP_PASS_VALUE_EXAMPLE=`zmlocalconfig -s ldap_root_password | grep "ldap_root_password" | cut -d'=' -f2 | tr -d ' '`
	else 
		echo You are currently logged in on a ZCS server as "$USER". Please install using the 'zimbra' user. 
		echo Installation will now exit.
		exit 0
	fi
fi

# CHECK IF THE DIRECTORY EXISTS AND IF THERE ARE CONTENTS
if [[ -d "${INSTALLPATH}" && ! -L "${INSTALLPATH}" ]] ; then
	if [ -f "${INSTALLPATH}/zimbracmsclient.properties" ]; then
	   echo "We have verified that this is an upgrade and will be upgrading using the existing configuration."
	   LDAP_URL_VALUE=`cat ${INSTALLPATH}/zimbracmsclient.properties | grep "ldap.url" | cut -d'=' -f2`
	   LDAP_PASS_VALUE=`cat ${INSTALLPATH}/zimbracmsclient.properties | grep "ldap.password" | cut -d'=' -f2`
	   ACCOUNT_ID_VALUE=`cat ${INSTALLPATH}/zimbracmsclient.properties | grep "account.id" | cut -d'=' -f2`
	   DEVICE_ID_VALUE=`cat ${INSTALLPATH}/zimbracmsclient.properties | grep "device.id" | cut -d'=' -f2`
	   echo ""
	   echo "LDAP URL: $LDAP_URL_VALUE"
	   #echo "LDAP PASSWORD: $LDAP_PASS_VALUE"
	   echo "CUSTOMER ID: $ACCOUNT_ID_VALUE"
	   echo "DEVICE ID: $DEVICE_ID_VALUE"
		read -p "Do you want to continue with the upgrade?  y/n: " UPGRADECONTINUE
		if [ $UPGRADECONTINUE == "n" ]; then
			echo "You have chosen to end the upgrade process."
			exit 0
		fi
	else
		read -p "The path specified exists but does not have the ZRT tool installed. Only one instance should be installed, do you want to continue?  y/n: " CONTINUE
		if [ $CONTINUE == "y" ]; then
			if which zmlocalconfig >/dev/null; then
				if [ "${USER}" = "zimbra" ]; then
					LDAP_URL_VALUE="$LDAP_URL_VALUE_EXAMPLE"
					LDAP_PASS_VALUE="$LDAP_PASS_VALUE_EXAMPLE"
				else
					echo "You have chosen to configure to a remote LDAP server, please insure that this is the only ZRT client querying this user repository, to insure that there are no double reporting:"
					read -p "Please input the LDAP URL value from running the command 'zmlocalconfig ldap_master_url': " LDAP_URL_VALUE
    				read -p "Please input the LDAP password value from running the command 'zmlocalconfig -s ldap_root_password': " LDAP_PASS_VALUE
    			fi
			else
				echo "You have chosen to configure to a remote LDAP server, please insure that this is the only ZRT client querying this user repository, to insure that there are no double reporting:"
				read -p "Please input the LDAP URL value from running the command 'zmlocalconfig ldap_master_url': " LDAP_URL_VALUE
    			read -p "Please input the LDAP password value from running the command 'zmlocalconfig -s ldap_root_password': " LDAP_PASS_VALUE
    		fi
			read -p "Please input the Customer ID provided to you from your Zimbra sales representative: " ACCOUNT_ID_VALUE
			DEVICE_ID_VALUE=$(echo $LDAP_URL_VALUE | awk -F/ '{print $3}' | awk -F ':' '/:/ {print $1}')
			if [ -z "$DEVICE_ID_VALUE" ]; then
				DEVICE_ID_VALUE="$LDAP_URL_VALUE"
			fi
		else
			echo "You have chose to end the upgrade process."
			exit 0;
		fi
	fi
fi

##############################
# VALIDATE INPUT SETTINGS    #
##############################
echo ""
echo "Testing input settings..."
testresult=$("$_java" -cp ZimbraCMSClient.jar com.flexerasoftware.zimbra.TestSettings "$LDAP_URL_VALUE" "$LDAP_PASS_VALUE" "$ACCOUNT_ID_VALUE" "$DEVICE_ID_VALUE" 2>&1)
#echo "Result: $testresult"
if [[ $testresult == *ERROR* ]]; then
	if [[ $testresult == *LDAP* ]]; then
		echo ""
		echo "We have been unable to verify your ldap server.  Please insure that your configuration is correct by running the following commands on the ldap server using the zimbra user:"
		echo "zmlocalconfig ldap_master_url"
		echo "zmlocalconfig -s ldap_root_password"
		echo "Also insure that you have telnet to the ldap server from this system." 
		echo "Ending installation of the ZRT client"
		exit 0
	elif [[ $testresult == *Customer* ]]; then
		echo ""
		echo "You have entered an invalid ZRT ID or the connection is timing out going to https://zimbra.compliance.flexnetoperations.com.  Please insure that the server can access zimbra.compliance.flexnetoperations.com on port 443 or to obtain  your ZRT ID please contact Zimbra Support.  Ending installation process."
		exit 0
	fi
  echo "There is an issue with the input values. Please verify and run the installer again.";
  exit 0
fi

##############################
# CREATE THE PROPERTIES FILE #
##############################
PROPERTY_FILE="zimbracmsclient.properties"
echo "## RESOURCE LOADING" > $PROPERTY_FILE
echo "resources.use.url = false;" >> $PROPERTY_FILE
echo "resources.file = $INSTALLPATH/ZimbraResources.properties" >> $PROPERTY_FILE
echo "resources.url = http://localhost/ZimbraResources.properties" >> $PROPERTY_FILE
echo "" >> $PROPERTY_FILE
echo "## SERVER URL" >> $PROPERTY_FILE
echo "ldap.url=$LDAP_URL_VALUE" >> $PROPERTY_FILE
echo "ldap.cn=cn=config" >> $PROPERTY_FILE
echo "ldap.password=$LDAP_PASS_VALUE" >> $PROPERTY_FILE
echo "ldap.output.debug=true" >> $PROPERTY_FILE
echo "" >> $PROPERTY_FILE
echo "endpoint.url=https://zimbra.compliance.flexnetoperations.com" >> $PROPERTY_FILE
echo "device.id=$DEVICE_ID_VALUE" >> $PROPERTY_FILE
echo "account.id=$ACCOUNT_ID_VALUE" >> $PROPERTY_FILE
echo "" >> $PROPERTY_FILE
echo "## CAPABILITIES FOR STANDARD EDITION FEATURES" >> $PROPERTY_FILE
echo "se.feature.name=SECount" >> $PROPERTY_FILE
echo "se.feature.version=1.0" >> $PROPERTY_FILE
echo "" >> $PROPERTY_FILE
echo "## CAPABILITIES FOR PROFESSIONAL EDITION FEATURES" >> $PROPERTY_FILE
echo "pe.feature.name=PECount" >> $PROPERTY_FILE
echo "pe.feature.version=1.0" >> $PROPERTY_FILE
echo "" >> $PROPERTY_FILE
echo "## CAPABILITIES FOR BUSINESS EDITION FEATURES" >> $PROPERTY_FILE
echo "be.feature.name=BECount" >> $PROPERTY_FILE
echo "be.feature.version=1.0" >> $PROPERTY_FILE
echo "" >> $PROPERTY_FILE
echo "## CAPABILITIES FOR BUSINESS EDITION PLUS FEATURES" >> $PROPERTY_FILE
echo "bep.feature.name=BEPCount" >> $PROPERTY_FILE
echo "bep.feature.version=1.0" >> $PROPERTY_FILE
echo "" >> $PROPERTY_FILE
echo "## CAPABILITIES FOR EWS" >> $PROPERTY_FILE
echo "ews.feature.name=EWSCount" >> $PROPERTY_FILE
echo "ews.feature.version=1.0" >> $PROPERTY_FILE


##############################
# COPY THE ZRT FILES         #
##############################
cp $PROPERTY_FILE $INSTALLPATH/.
cp ZimbraResources.properties $INSTALLPATH/.
cp -R libs $INSTALLPATH/.
cp ZimbraCMSClient.jar $INSTALLPATH/.
# DO THE OTHERS

##############################
# CREATE THE RUN FILE #
##############################
RUNFILE="$INSTALLPATH/run.sh"
echo "#!/bin/bash" > $RUNFILE
echo "" >>  $RUNFILE
echo "if which java >/dev/null; then" >>  $RUNFILE
echo "    cd $INSTALLPATH && java -jar $INSTALLPATH/ZimbraCMSClient.jar -p $INSTALLPATH/zimbracmsclient.properties" >>  $RUNFILE
echo "else" >>  $RUNFILE
echo "    if [ -z \${JAVA_HOME} ]" >>  $RUNFILE
echo "	    then" >>  $RUNFILE
echo "	        echo There was not a JAVA_HOME set.  Please set a JAVA_HOME system variable." >>  $RUNFILE
echo "          exit " >> $RUNFILE
echo "" >>  $RUNFILE	        
echo "	    else " >>  $RUNFILE
echo "	        cd $INSTALLPATH && \${JAVA_HOME}/bin/java -jar $INSTALLPATH/ZimbraCMSClient.jar -p $INSTALLPATH/zimbracmsclient.properties" >>  $RUNFILE
echo "	fi" >>  $RUNFILE
echo "fi" >>  $RUNFILE

##############################
# SET THE PERMISSIONS        #
##############################
chmod -R 755 $INSTALLPATH

##############################
# Write out current crontab  #
##############################

crontab -l > systemcron
cp systemcron systemcron.OLD
if grep -Fxq "0 2 */3 * * $RUNFILE" systemcron
then
    echo ""
    if which zmlocalconfig >/dev/null; then
		if [ "${USER}" = "zimbra" ]; then
			echo "Cron job has already been added.  Replacing with new CRON."
			#echo "s/^0 2 \*\/3 \* \* \/opt\/zrt\/run.sh/0 2 \*\/3 \* \* \. $HOME\/\.bashrc; $RUNFILE;/g"
			sed -e 's/^0 2 \*\/3 \* \* \/opt\/zrt\/run.sh/#/g' systemcron > newcron
			cp newcron systemcron
			echo Added new cron job into cron file.
			echo "0 2 */3 * * . $HOME/.bashrc; $RUNFILE;" >> systemcron
			##############################
			#install new cron file       #
			##############################
			crontab systemcron
			rm newcron
		fi
	else
	    echo "Cron job has already been added."
	fi
elif grep -Fxq "0 2 */3 * * . $HOME/.bashrc; $RUNFILE;" systemcron
then
	echo ""
    echo "Cron job has already been added."
else
	cp systemcron systemcron.OLD
	echo Adding new cron into cron file
	if which zmlocalconfig >/dev/null; then
		if [ "${USER}" = "zimbra" ]; then
			echo "0 2 */3 * * . $HOME/.bashrc; $RUNFILE;" >> systemcron
			echo " " >> systemcron
		fi
	else 
		echo "0 2 */3 * * $RUNFILE" >> systemcron
		echo " " >> systemcron
		echo We have recognized that this is not a ZCS server and we will be adding the following to the crontab:
		echo
		echo "0 2 */3 * * $RUNFILE"
		echo
		echo This entry must be manually verified and updated or your reporting may not occur.  
	fi
	##############################
	#install new cron file       #
	##############################
	crontab systemcron
fi
rm systemcron

##############################
# TEST THE APPLICATION       #
##############################
#read -p "The installation will now be tested, press enter to continue: " RUN_APP
#if [ "$RUN_APP" = "n" ]; then
#	echo "Bypassing test run"
#else 
	echo ""
	echo "##############################"
	echo "Running the ZRT Reporting Tool..."
	echo "Please verify the data within the user portal at https://zimbra.flexnetoperations.com"
	echo "##############################"
	echo ""
	$RUNFILE
#fi

