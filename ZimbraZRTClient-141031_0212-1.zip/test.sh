#!/bin/sh

if which java >/dev/null; then
    java -jar ZimbraCMSClient.jar -p zimbracmsclient.properties -dryrun
else
    if [ -z ${JAVA_HOME} ]
	    then
	        echo There was not a JAVA_HOME set.  Please set a JAVA_HOME system variable.
	        
	    else 
	        ${JAVA_HOME}/bin/java -jar ZimbraCMSClient.jar -p zimbracmsclient.properties -dryrun
	fi
fi
